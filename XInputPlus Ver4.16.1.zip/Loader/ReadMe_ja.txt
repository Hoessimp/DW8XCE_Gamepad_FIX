** XInputPlusLoader Ver4.16

XInputPlusLoader.exeは、ショートカットおよびコンソールからの実行用に以下のコマンドラインオプションを指定することができます。
コマンドラインオプションを何も指定しない場合にはGUIが表示されます。

使用法: XInputPlusLoader [Option] TargetProgram args
[Option]: /C 子プロセスも対象とします。
[Option]: /P 実行中のプロセスにXInput Plusを注入します。この時、TargetProgramにはプロセス名・プロセスの実行パス・プロセスIDのいずれかを指定できます。
