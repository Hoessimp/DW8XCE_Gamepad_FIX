** XInputPlusLoader Ver4.16

XInputPlusLoader.exe can use the following command line options when run from shortcuts and from the console.
If no command line options are specified, the GUI is displayed.

usage: XInputPlusLoader [Option] TargetProgram args
[Option]: /C Hook Child Process
[Option]: /P Inject XInput Plus into running process.TargetProgram can be either process name, executable file name or process ID.
