XInput Plus Winmm Wrapper (4.15) 

(c) 0dd14Lab 2019
https://sites.google.com/site/0dd14lab/

*********************************************************************************
** What's this 

This is a Wapper DLL of Winmm.dll for Xinput Plus ver4.15.
This changes a JoyGetPos/JoyGetPosEx call of application to XInput call and makes
the functions of XinputPlus effective.


*********************************************************************************
** Usage

1. Apply XInputPlus to target program (Enable the DirectInput-Output function.)

*Winmm Wrapper does not require a DirectInputDLLs.This refers to the DirectInput 
settings of ini file.

2. Place the Winmm.dll in the folder of the target program.


*********************************************************************************
** Notes

This Wapper only supports 32bit application.

