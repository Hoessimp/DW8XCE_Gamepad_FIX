HelixMod Autoload - use it when you can't run the game directly (like Steam games). It includes patched HelixMod dll, that loads tmldr.dll
(used for automatic tpf files loading from texmod folder) that loads tmrls.dll (texmod dll).
Loader - .net exe texmod loader
TexMod - original TexMod

